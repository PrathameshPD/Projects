from turtle import pd
import streamlit as st
from ftgFinal import data, plt
import h5py


#Data Manipulation-----------
import pandas as pd
import numpy as np

#Data Visualization----------
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import numpy as np

#Data Preprocessing-----------
from sklearn.model_selection import train_test_split 

#Model-----------------------
from sklearn.linear_model import SGDClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix

#Metrics----------------------
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score 


# find more emojis here:// https://www.webfx.com/tools/emoji-cheat-sheet/
st.set_page_config(page_title="FASTAG", page_icon=":tada:")


st.title("MINOR PROJECT")
st.write("[Click here to view the presentation>](https://docs.google.com/presentation/d/1Kd-4qHPAi-dduYmxvNDQidX4cTIQhbCc/edit#slide=id.p1)")
st.write("---")
st.write("Under the Guidance of :-  Dr. S. Senthil (Director School of CSA)")
st.write("---")
st.write("MSc Data Science - Prathamesh - 041 / Nikhil - 035")
st.write("---")
st.title("Enchancing Integrity of Toll Gate Revenue: Fastag Fraud Detection")
st.write("In recent years, the adoption of electronic toll collection systems, particularly FastTag, has revolutionized the way tolls are collected at toll gates. FastTag offers a seamless and efficient method for motorists to pay tolls electronically, eliminating the need for cash transactions and significantly reducing traffic congestion. However, as with any technological advancement, there is a need to ensure the integrity of the system and prevent fraudulent activities that could undermine the revenue collection process.")
st.write("One of the primary challenges in maintaining the integrity of toll gate revenue is the potential for FastTag fraud. This can occur when dishonest individuals attempt to manipulate or exploit the electronic toll collection system to avoid paying the correct toll amount. To address this concern, a robust FastTag fraud detection system becomes crucial in safeguarding the revenue generated through toll collections.")
st.write("A key aspect of FastTag fraud detection involves cross-checking the amount paid by motorists using FastTag with the fixed toll prices set by the authorities. By establishing a real-time verification process, toll gate operators can identify instances where the paid amount deviates from the prescribed toll fee. This cross-checking mechanism serves as an effective means to detect and prevent fraudulent activities related to FastTag usage.")
st.write("The implementation of a reliable FastTag fraud detection system involves leveraging advanced technologies such as data analytics, machine learning, and artificial intelligence. These technologies enable the continuous monitoring of transactions, identifying patterns indicative of potential fraud, and triggering alerts for immediate investigation.")
st.write("Furthermore, the FastTag fraud detection system can be designed to analyze historical transaction data to identify irregularities or suspicious trends. This proactive approach allows toll gate authorities to preemptively address potential fraud risks and enhance the overall integrity of the toll collection process.")
if st.button("Click me"):
   st.write("[Behind-the-screens>](https://github.com/PrathameshPD/FasTagDE/blob/main/ftgFinal.py)")

with st.container():
    st.write("---")
    st.write("Top 5 Dataset")
    st.dataframe(data.head())

with st.container():
    st.write("---")
    st.header("Scope of the Problem")
    st.write("The scope of the problem revolves around the accurate categorization of vehicles at toll gates to ensure fair and appropriate toll charges.")
    st.write("The issue is particularly prominent in the context of Fast lag transactions, where vehicles may attempt to misrepresent their category to pay a lower toll fee.") 
    st.write("The problem encompasses the need for a robust system that can reliably identify whether a vehicle is an XUV, Sedan, or Mini Car during FastTag transactions.")
    st.write("Key aspects of the problem include:")
    st.write("1. Categorization Accuracy")
    st.write("2. Fraud Detection")

with st.container():
    st.write("---")
    st.write("visualizes the count of transactions by vehicle type using a countplot.")
    plt.figure(figsize=(10, 6))
    sns.countplot(x='Vehicle_Type', data=data)
    plt.title('Count of Transactions by Vehicle Type')
    plt.xlabel('Vehicle Type')
    plt.ylabel('Transaction Count')
    st.pyplot()
    st.set_option('deprecation.showPyplotGlobalUse', False)

with st.container():
    st.write("---")
    st.write("visualizes the distribution of lane types using a countplot")
    plt.figure(figsize=(8, 5))
    sns.countplot(x='Lane_Type', data=data, palette='pastel')
    plt.title('Distribution of Lane Types')
    plt.xlabel('Lane Type')
    plt.ylabel('Count')
    st.pyplot()
    st.set_option('deprecation.showPyplotGlobalUse', False)

with st.container():
    st.write("---")
    st.write("visualizes the distribution of transaction amount using a histogram")
    plt.figure(figsize=(10, 6))
    sns.histplot(data['Amount_paid'], bins=30, kde=True, color='blue')
    plt.title('Distribution of Amount_paid')
    plt.xlabel('Amount paid')
    plt.ylabel('Frequency')
    st.pyplot()
    st.set_option('deprecation.showPyplotGlobalUse', False)

with st.container():
    st.write("---")
    st.write("Toll Booth Activity: Visualize the distribution of transactions and total revenue across different toll booths using bar charts or heatmaps. This can reveal busy locations and potential revenue hotspots.")
    plt.figure(figsize=(10, 6))
    data.groupby("TollBoothID").agg(count=("Transaction_ID", "count"), revenue=("Transaction_Amount", "sum")).plot(kind="bar", stacked=True)
    plt.title("Toll Booth Activity Distribution")
    plt.xlabel("Toll Booth ID")
    plt.ylabel("Count (left axis), Revenue (right axis)")
    st.pyplot()
    st.set_option('deprecation.showPyplotGlobalUse', False)

with st.container():
    st.write("---")
    st.write("Lane Usage Comparison: Compare the distribution of transactions and average transaction amount across different lane types (ETC vs Manual) using bar charts or boxplots. This can highlight potential efficiency differences.")
    # Lane usage comparison
    plt.figure(figsize=(10, 6))
    data.groupby("Lane_Type").agg(count=("Transaction_ID", "count"), mean_amount=("Transaction_Amount", "mean")).plot(kind="bar")
    plt.title("Lane Usage Comparison")
    plt.xlabel("Lane Type")
    plt.ylabel("Count (left axis), Average Amount (right axis)")
    st.pyplot()
    st.set_option('deprecation.showPyplotGlobalUse', False)

with st.container():
    st.write("---")
    st.write("visualizes the distribution of transaction amount for different lane types using a boxplot.")
    # Boxplot of transaction amount by lane type
    plt.figure(figsize=(10, 6))
    sns.boxplot(x="Lane_Type", y="Transaction_Amount", showmeans=True, data=data)
    plt.title("Distribution of Transaction Amount by Lane Type")
    st.pyplot()
    st.set_option('deprecation.showPyplotGlobalUse', False)

with st.container():
    st.write("---")
    st.write("visualizes the distribution of transaction amount for fraudulent and non-fraudulent transactions using a boxplot.")
    # Boxplot of transaction amount by fraud indicator
    plt.figure(figsize=(10, 6))
    sns.boxplot(x="Fraud_indicator", y="Transaction_Amount", showmeans=True, data=data)
    plt.title("Distribution of Transaction Amount by Fraud Indicator")
    st.pyplot()
    st.set_option('deprecation.showPyplotGlobalUse', False)


with st.container():
    st.write("---")
    st.write("Confusion Matrix")
    # Preprocess the data, e.g., handle missing values, convert categorical variables to numerical, etc.
# Select relevant features and target variable
# Feature selection
features = ['Transaction_Amount', 'Amount_paid', 'Vehicle_Type', 'Lane_Type', 'Geographical_Location']
X = data[features]
y = data['Fraud_indicator']
# Convert categorical features to numerical using one-hot encoding
X = pd.get_dummies(X, columns=['Transaction_Amount', 'Amount_paid', 'Vehicle_Type', 'Lane_Type', 'Geographical_Location'], drop_first=True)
# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
# Define a list of classifiers
classifiers = [
    LogisticRegression(random_state=42),
    SGDClassifier(random_state=42),
    GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, random_state=42),
    SVC(kernel='linear', random_state=42),
    KNeighborsClassifier(n_neighbors=5),
]
# Dictionary to store results
results = {}
# Iterate through classifiers
for clf in classifiers:
    clf_name = clf.__class__.__name__
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    # Store results
    results[clf_name] = {
        'Accuracy': accuracy*100,
        'Precision': precision*100,
        'Recall': recall*100,
        'F1 Score': f1*100
    }
    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Not Fraud', 'Fraud'], yticklabels=['Not Fraud', 'Fraud'])
    plt.title(f'Confusion Matrix - {clf_name}')
    cm_plot = st.pyplot()
# Create results table
results_data = pd.DataFrame(results).T

# Display results on the Streamlit app
st.header("Model Performance Results")
st.table(results_data)

with st.container():
     st.write("---")
     # Dictionary to store results, including train and test accuracy
results = {}

# Iterate through classifiers
for clf in classifiers:
    clf_name = clf.__class__.__name__

    # Fit the model on the training set
    clf.fit(X_train, y_train)

    # Calculate train accuracy
    y_train_pred = clf.predict(X_train)
    train_accuracy = accuracy_score(y_train, y_train_pred)

    # Calculate test accuracy
    y_test_pred = clf.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_test_pred)

    # Store results, including train and test accuracy
    results[clf_name] = {
        'Train Accuracy': train_accuracy * 100,
        'Test Accuracy': test_accuracy * 100,
        'Precision': precision_score(y_test, y_test_pred) * 100,
        'Recall': recall_score(y_test, y_test_pred) * 100,
        'F1 Score': f1_score(y_test, y_test_pred) * 100
    }

# Display results, including train and test accuracy
results_data = pd.DataFrame(results).T
st.table(results_data)

with st.container():
     st.write("---")
     st.header("One small step for Prathamesh & Nikhil, a giant leap for machine learning")
     st.write("Motivated by - One small step for man, one giant leap for mankind. ~ Neil Armstrong")
     st.write("[Review our Kaggle contribution>](https://www.kaggle.com/datasets/thegoanpanda/fastag-fraud-detection-datesets-fictitious)")
image_path = "C:\\Users\\Panda\\Desktop\\Screenshot 2024-01-25 110947.png"  # Replace with your actual image path
image = Image.open(image_path)
image_array = np.array(image)
fig, ax = plt.subplots()
ax.imshow(image_array)
ax.axis('off')  # Remove axes
st.pyplot(plt.gcf())  # Display the current figure

with st.container():
     st.write("---")
     st.header("Model Testing")
     st.subheader("To find out the model performance")
with h5py.File('results.h5', 'r') as f:
    loaded_results = pd.DataFrame(f['results'][:])

# Assign meaningful row and column names
loaded_results.index = [
   "LogisticRegression",
   "SGDClassifier",
   "GradientBoostingClassifier",
   "SVC",
   "KNeighborsClassifier",
]
loaded_results.columns = [
   "train_accuracy",
   "test_accuracy",
   "precision",
   "recall",
   "f1_score",
]

uploaded_file = st.file_uploader("Upload a CSV file", type="csv")
if uploaded_file is not None:
   data = pd.read_csv(uploaded_file)
   st.write("File uploaded successfully!")
   st.write("---")
   # Display a preview of the data
   st.dataframe(data.head())
   st.write("---")
   st.write("Results from the dataset!")
   st.dataframe(loaded_results)  # Display the results with updated names










